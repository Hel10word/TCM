#! /bin/sh
help()
{
    cat <<- EOF
Desc: mysql_export is used to export a specified table from MySQL Server as CSV file.

Usage:
  mysql_export.sh [options]

Connection options:
  -h, --host HOSTNAME       database server host (default: "localhost")
  -P, --port PORT           database server port (default: "3306")
  -u, --username USERNAME   database user name
  -p, --password PASSWORD   password of specified database user
  -d, --database DBNAME     database name to connect to
  -t, --table TABLE         table name to export
Output options:
  -f, --file FILE           path to output file
EOF
  exit 0
}

port=3306
host=localhost

while [[ $# -gt 0 ]]
do
  arg="$1"

  case $arg in
    --help)
      help
      ;;
    -h)
      host=$2
      shift
      ;;
    --host)
      host=$2
      shift
      ;;
    -P)
      port=$2
      shift
      ;;
    --port)
      port=$2
      shift
      ;;
    -u)
      username=$2
      shift
      ;;
    --username)
      username=$2
      shift
      ;;
    -p)
      password=$2
      shift
      ;;
    --password)
      password=$2
      shift
      ;;
    -d)
      dbname=$2
      shift
      ;;
    --database)
      dbname=$2
      shift
      ;;
    -t)
      table=$2
      shift
      ;;
    --table)
      table=$2
      shift
      ;;
    -f)
      file=$2
      shift
      ;;
    --file)
      file=$2
      shift
      ;;
    *)
      echo "Unknown option: ${arg}"
      exit 1
      ;;
  esac
  shift
done


mysql -u$username -p$password -h$host -P $port --database $dbname -sN -e "select * from $table"  | sed 's/"/""/g;s/^/"/;s/$/"/;s/\t/","/g;s/\n//g' > $file
