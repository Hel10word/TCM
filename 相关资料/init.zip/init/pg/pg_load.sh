#! /bin/sh
help()
{
    cat <<- EOF
Desc: pg_load is used to load a CSV file to a specified table of PostgreSQL Server.

Usage:
  pg_load.sh [options]

Connection options:
  -h, --host HOSTNAME       database server host (default: "localhost")
  -P, --port PORT           database server port (default: "5432")
  -u, --username USERNAME   database user name
  -p, --password PASSWORD   password of specified database user
  -d, --database DBNAME     database name to connect to
  -t, --table TABLE         table name to load
  -b, --batch BATCH SIZE    batch size when loading
Output options:
  -f, --file FILE           path to input file
EOF
  exit 0
}

port=5432
host=localhost
batch=10000

while [[ $# -gt 0 ]]
do
  arg="$1"

  case $arg in
    --help)
      help
      ;;
    -h)
      host=$2
      shift
      ;;
    --host)
      host=$2
      shift
      ;;
    -P)
      port=$2
      shift
      ;;
    --port)
      port=$2
      shift
      ;;
    -u)
      username=$2
      shift
      ;;
    --username)
      username=$2
      shift
      ;;
    -p)
      password=$2
      shift
      ;;
    --password)
      password=$2
      shift
      ;;
    -d)
      dbname=$2
      shift
      ;;
    --database)
      dbname=$2
      shift
      ;;
    -t)
      table=$2
      shift
      ;;
    --table)
      table=$2
      shift
      ;;
    -b)
      batch=$2
      shift
      ;;
    --batch)
      batch=$2
      shift
      ;;
    -f)
      file=$2
      shift
      ;;
    --file)
      file=$2
      shift
      ;;
    *)
      echo "Unknown option: ${arg}"
      exit 1
      ;;
  esac
  shift
done

export PGPASSWORD=$password

mkdir -p /tmp/cdc_init/tmp
split -l $batch -a 99 $file /tmp/cdc_init/tmp/data
for data in `ls /tmp/cdc_init/tmp`
do
psql -h $host -p $port -U $username -d $dbname -c "\copy $table from '"/tmp/cdc_init/tmp/$data"' with csv;"
done

rm -rf /tmp/cdc_init/tmp
